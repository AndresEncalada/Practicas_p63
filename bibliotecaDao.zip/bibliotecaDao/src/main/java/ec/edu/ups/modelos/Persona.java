package ec.edu.ups.modelos;

public abstract class Persona {
	//Atributos
	String nombre;
	int identificacion;
	//Metodo abstracto
	public abstract void mostrarInformacion();
}
